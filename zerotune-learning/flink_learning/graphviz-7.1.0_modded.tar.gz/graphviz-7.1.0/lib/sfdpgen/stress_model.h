#pragma once

void stress_model(int dim, SparseMatrix D, double **x, int edge_len_weighted, int maxit, double tol, int *flag);
