#pragma once

// maximum number of bytes needed to print a NUL-terminated int
enum { CHARS_FOR_NUL_TERM_INT = 12 };
