#pragma once

#include <common/geom.h>
#include <common/textspan.h>

char *gd_psfontResolve(PostscriptAlias *pa);
